create unique index PRIMARY_KEY_F
    on PRODUCTS (ID);

