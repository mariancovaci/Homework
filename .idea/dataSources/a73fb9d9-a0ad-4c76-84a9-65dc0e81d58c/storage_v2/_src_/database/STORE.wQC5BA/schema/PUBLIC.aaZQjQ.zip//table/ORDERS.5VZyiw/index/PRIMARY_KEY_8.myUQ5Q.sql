create unique index PRIMARY_KEY_8
    on ORDERS (ID);

